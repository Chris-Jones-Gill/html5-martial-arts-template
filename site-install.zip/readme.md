About This Project
==================

This is an example website for a martial arts business from KISS Web Design.  
  
It is responsive, uses HTML5 and CSS3, and requires SASS and Compass if you want to build it yourself
  
------------    
  
Contact info  
============  
  
 * Via github:		
	+ [https://github.com/KISS-Web-Design](https://github.com/KISS-Web-Design "Link to KISS Web Design Github page")  
 * Via website:	
	+ [http://kisswebdesign.co.uk](http://kisswebdesign.co.uk/contact "Link to the KISS Web Design contact page")  
 * Via Twitter:	
	+ [@KissWebDesign](https://twitter.com/KissWebDesign "Twitter link for KISS Web Design")  
 * Via Facebook:	
	+ [http://www.facebook.com/pages/Kiss-Web-Design-Ltd](http://www.facebook.com/KissWebDesign"Link to the KISS Web Design Facebook Page")  
  
------------ 
    
User Information
================

 * This is a personal template project by KISS Web Design, it is not meant for general use - but feel free to use it if you want.
 * There is no support for this project, if I change something and it breaks your website that is not my problem - you have been warned!
  
------------  
     
LICENCES
========
 * This project is released under the GPL version 3
   See GP:_v3.txt for full terms.
  
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see http://www.gnu.org/licenses.

 * modernizr.custom.11330.js is released under a dual MIT & BSD license
   See mit-license.txt for full terms

------------  
  
COPYRIGHTS
==========

 * scss, css and html files
   (C) 2013 KISS Web Design
   
 * images
   (C) Original designers.
   
 * modernizr
   (c) modernizr.com
   
 * Compass
   (c) Christopher M. Eppstein 
   Documsntation is licensed under a [Creative Commons Attribution-Noncommercial-Share Alike 3.0 United States License](http://creativecommons.org/licenses/by-nc-sa/3.0/us/ "Creative commons license website").
   Permissions beyond the scope of this license may be available at http://compass-style.org/copyright/.
   
 * SASS
   (c) [2006-2013 Hampton Catlin, Nathan Weizenbaum, Chris Eppstein, and numerous contributors](http://sass-lang.com/  "SASS homepage"). 

